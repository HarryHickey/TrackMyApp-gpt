# TrackMyMatch

Colourful, interactive sports dashboard (Football + Darts) built with Vite + React.

## Run locally
```bash
npm install
npm run dev
```

## Build & preview
```bash
npm run build
npm run preview
```

## Push to GitHub
### Using GitHub CLI (recommended)
```bash
bash scripts/push_https.sh <your-github-username> trackmymatch
# or SSH:
# bash scripts/push_ssh.sh <your-github-username> trackmymatch
```

### Manual
```bash
git init -b main
git add .
git commit -m "Initial commit: TrackMyMatch"
git remote add origin https://github.com/<your-username>/trackmymatch.git
git push -u origin main
```
