#!/usr/bin/env bash
set -euo pipefail
USER=${1:-}
REPO=${2:-trackmymatch}
if [[ -z "$USER" ]]; then
  echo "Usage: $0 <github-username> [repo-name]"
  exit 1
fi
git init -b main
git add .
git commit -m "Initial commit: TrackMyMatch"
if command -v gh >/dev/null 2>&1; then
  gh repo create "$USER/$REPO" --public --source . --remote origin --push
else
  echo "gh CLI not found; create the repo at https://github.com/new (no README)."
  echo "Then run:"
  echo "  git remote add origin https://github.com/$USER/$REPO.git"
  echo "  git push -u origin main"
fi
