# TrackMyMatch Preview

A lightweight Vite + React project generated from your canvas preview.

## Run locally

```bash
npm install
npm run dev
```

Then open the printed local URL in your browser.

## Build for production

```bash
npm run build
npm run preview
```

This is an in-memory demo (no backend). Wire up persistence with a simple API or localStorage.
