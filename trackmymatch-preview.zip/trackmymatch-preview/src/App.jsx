import React, { createContext, useContext, useMemo, useState } from "react";

// ⚽️🎯 TrackMyMatch — colourful, interactive, sports-focused web preview
// - Sports: Football & Darts
// - Dashboard: upcoming fixtures, recent results, player leaderboards
// - Per-sport sections with sport-specific stats
// - In-app editors for leagues, teams, players & stats
// - Contact Us section
// - Banner ad space at the bottom

// ===== Theme =====
const palette = {
  bg: "#0B1026",
  card: "#0F1533",
  ink: "#ECF2FF",
  sub: "#96A2C9",
  border: "#223",
  accent: "#7CFF8D", // neon green
  accent2: "#7DD3FC", // sky blue
  accent3: "#FCA5A5", // salmon
  gold: "#FBBF24",
  red: "#EF4444",
  blue: "#60A5FA",
  pink: "#F472B6",
};

const styles = {
  page: {
    minHeight: "100vh",
    background: `radial-gradient(1200px 800px at 10% 0%, #1A2150 0%, ${palette.bg} 60%)`,
    fontFamily: "Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial",
    color: palette.ink,
  },
  container: { maxWidth: 1100, margin: "0 auto", padding: 24 },
  header: {
    position: "sticky",
    top: 0,
    zIndex: 10,
    backdropFilter: "saturate(120%) blur(8px)",
    background: "rgba(10, 15, 40, 0.8)",
    borderBottom: `1px solid ${palette.border}`,
  },
  brand: { display: "flex", alignItems: "center", gap: 12, fontWeight: 800, letterSpacing: 0.3 },
  brandBadge: {
    width: 34,
    height: 34,
    borderRadius: 10,
    background: `linear-gradient(135deg, ${palette.accent} 0%, ${palette.accent2} 100%)`,
    display: "grid",
    placeItems: "center",
    color: "#07131A",
    fontWeight: 900,
  },
  nav: { display: "flex", gap: 8, flexWrap: "wrap" },
  tab: (active) => ({
    padding: "8px 12px",
    borderRadius: 12,
    border: `1px solid ${active ? palette.accent : ${"palette.border"}}`,
    background: active ? "rgba(124,255,141,0.12)" : "transparent",
    color: active ? palette.accent : palette.sub,
    cursor: "pointer",
    fontWeight: 600,
  }),
  grid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 },
  card: {
    background: `linear-gradient(180deg, ${palette.card}, #0B122A)`,
    border: `1px solid ${palette.border}`,
    borderRadius: 16,
    padding: 18,
    boxShadow: "0 10px 30px rgba(0,0,0,0.25)",
  },
  h1: { fontSize: 28, fontWeight: 800, margin: "0 0 8px" },
  h2: { fontSize: 18, fontWeight: 700, opacity: 0.9, margin: "0 0 8px" },
  small: { fontSize: 12, color: palette.sub },
  btn: {
    padding: "10px 12px",
    borderRadius: 10,
    border: `1px solid ${palette.border}`,
    background: "transparent",
    color: palette.ink,
    cursor: "pointer",
    fontWeight: 600,
  },
  btnPrimary: {
    borderColor: palette.accent,
    background: "rgba(124,255,141,0.12)",
    color: palette.accent,
  },
  input: {
    width: "100%",
    padding: "10px 12px",
    borderRadius: 10,
    border: `1px solid ${palette.border}`,
    background: "#0A1230",
    color: palette.ink,
    outline: "none",
  },
  table: {
    width: "100%",
    borderCollapse: "separate",
    borderSpacing: "0 8px",
    fontSize: 14,
  },
  th: { textAlign: "left", color: palette.sub, fontWeight: 600, padding: "6px 8px" },
  td: { padding: "10px 8px", background: "rgba(255,255,255,0.02)", borderTopLeftRadius: 8, borderBottomLeftRadius: 8 },
  tdR: { padding: "10px 8px", textAlign: "right", background: "rgba(255,255,255,0.02)", borderTopRightRadius: 8, borderBottomRightRadius: 8 },
  hero: {
    display: "grid",
    gridTemplateColumns: "1fr 300px",
    gap: 16,
    alignItems: "center",
  },
  banner: {
    position: "sticky",
    bottom: 0,
    background: "#0A0F25",
    borderTop: `1px solid ${palette.border}`,
    padding: 12,
    display: "flex",
    justifyContent: "center",
  },
};

// ===== Data Layer =====
const DataCtx = createContext(null);
function DataProvider({ children }) {
  const [state, setState] = useState({
    sports: {
      football: {
        name: "Football",
        cover: "data:image/svg+xml;utf8,<?xml version='1.0'?><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 72'><defs><linearGradient id='g' x1='0' x2='1'><stop stop-color='%237CFF8D'/><stop offset='1' stop-color='%237DD3FC'/></linearGradient></defs><rect width='128' height='72' rx='12' fill='%230C163A'/><circle cx='32' cy='36' r='18' fill='url(%23g)' opacity='0.8'/><path d='M26 36h12M32 30v12' stroke='%230B1026' stroke-width='3' stroke-linecap='round'/><rect x='64' y='22' width='48' height='28' rx='6' fill='url(%23g)' opacity='0.3'/><path d='M64 36h48' stroke='%237CFF8D' stroke-width='3' opacity='0.6'/></svg>",
        leagues: [
          { id: "fl1", name: "East London League", location: "London", teams: ["Hackney FC", "Stratford Rovers", "Bow United"] },
        ],
        players: [
          { id: "fp1", name: "Alex Byrne", team: "Hackney FC", goals: 7, assists: 3, yellow: 2, red: 0 },
          { id: "fp2", name: "Mo Silva", team: "Stratford Rovers", goals: 5, assists: 6, yellow: 1, red: 0 },
        ],
        fixtures: [
          { id: "ffx1", date: "2025-10-12", home: "Hackney FC", away: "Bow United" },
          { id: "ffx2", date: "2025-10-19", home: "Stratford Rovers", away: "Hackney FC" },
        ],
        results: [
          { id: "fr1", date: "2025-09-14", home: "Bow United", away: "Hackney FC", score: "1-2" },
          { id: "fr2", date: "2025-09-07", home: "Stratford Rovers", away: "Bow United", score: "3-0" },
        ],
      },
      darts: {
        name: "Darts",
        cover: "data:image/svg+xml;utf8,<?xml version='1.0'?><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 72'><defs><linearGradient id='d' x1='0' x2='1'><stop stop-color='%23F472B6'/><stop offset='1' stop-color='%23FBBF24'/></linearGradient></defs><rect width='128' height='72' rx='12' fill='%230C163A'/><circle cx='36' cy='36' r='22' fill='url(%23d)' opacity='0.8'/><circle cx='36' cy='36' r='6' fill='%230B1026'/><rect x='64' y='26' width='48' height='20' rx='10' fill='url(%23d)' opacity='0.3'/><path d='M64 36h48' stroke='%23FBBF24' stroke-width='3' opacity='0.6'/></svg>",
        leagues: [
          { id: "dl1", name: "Shoreditch Darts League", location: "London", teams: ["Flight Club A", "Oche Masters"] },
        ],
        players: [
          { id: "dp1", name: "Jess Taylor", team: "Flight Club A", threeDartAvg: 78.5, highestCheckout: 121, "180s": 3 },
          { id: "dp2", name: "Liam O'Neill", team: "Oche Masters", threeDartAvg: 74.2, highestCheckout: 105, "180s": 2 },
        ],
        fixtures: [
          { id: "dfx1", date: "2025-10-10", home: "Flight Club A", away: "Oche Masters" },
        ],
        results: [
          { id: "dr1", date: "2025-09-12", home: "Oche Masters", away: "Flight Club A", score: "5-7" },
        ],
      },
    },
  });
  const value = useMemo(() => ({ state, setState }), [state]);
  return <DataCtx.Provider value={value}>{children}</DataCtx.Provider>;
}
const useData = () => {
  const ctx = useContext(DataCtx);
  if (!ctx) throw new Error("useData must be used within DataProvider");
  return ctx;
};

// ===== Utilities =====
const fmtDate = (d) => new Date(d + "T00:00:00").toLocaleDateString(undefined, { day: "2-digit", month: "short" });
const upcoming = (list) => list.filter((f) => new Date(f.date) >= new Date());
const recent = (list) => list.filter((r) => new Date(r.date) < new Date());

// ===== Components =====
function Stat({ label, value, hint, tone = "accent" }) {
  const color = { accent: palette.accent, blue: palette.blue, pink: palette.pink, gold: palette.gold }[tone];
  return (
    <div style={{ ...styles.card, padding: 16 }}>
      <div style={{ fontSize: 12, color: palette.sub }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 800, color }}>{value}</div>
      {hint && <div style={{ fontSize: 12, color: palette.sub }}>{hint}</div>}
    </div>
  );
}

function FixtureList({ title, items }) {
  return (
    <div style={styles.card}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
        <h3 style={styles.h2}>{title}</h3>
        <div style={styles.small}>{items.length} items</div>
      </div>
      <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
        {items.map((fx) => (
          <li key={fx.id} style={{ display: "grid", gridTemplateColumns: "100px 1fr 100px", gap: 8, padding: "10px 0", borderBottom: `1px dashed ${palette.border}` }}>
            <div style={{ color: palette.sub }}>{fmtDate(fx.date)}</div>
            <div>{fx.home} <span style={{ color: palette.sub }}>vs</span> {fx.away}</div>
            {fx.score ? <div style={{ textAlign: "right", fontWeight: 700 }}>{fx.score}</div> : <div />}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Leaderboard({ sportKey }) {
  const { state } = useData();
  const sport = state.sports[sportKey];
  const rows = sportKey === "football"
    ? sport.players.map((p) => ({ name: p.name, team: p.team, statA: p.goals, statALabel: "Goals", statB: p.assists, statBLabel: "Assists" }))
    : sport.players.map((p) => ({ name: p.name, team: p.team, statA: p.threeDartAvg, statALabel: "3-dart avg", statB: p["180s"], statBLabel: "180s" }));

  return (
    <div style={styles.card}>
      <h3 style={styles.h2}>{sport.name} — Player Leaderboard</h3>
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>Player</th>
            <th style={styles.th}>Team</th>
            <th style={styles.th}>Stat A</th>
            <th style={styles.th}>Stat B</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, idx) => (
            <tr key={idx}>
              <td style={{ ...styles.td, borderTopLeftRadius: 8 }}>{r.name}</td>
              <td style={styles.td}>{r.team}</td>
              <td style={styles.td}>{r.statA}</td>
              <td style={{ ...styles.tdR, borderTopRightRadius: 8 }}>{r.statB}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Cover({ svg, title }) {
  return (
    <div style={{ ...styles.card, display: "grid", gridTemplateColumns: "1fr 140px", gap: 16, alignItems: "center" }}>
      <div>
        <h2 style={{ ...styles.h2, margin: 0 }}>{title}</h2>
        <div style={styles.small}>Tap into stats, fixtures and edit data live.</div>
      </div>
      <img alt="cover" src={svg} style={{ width: 140, height: 78, borderRadius: 12, objectFit: "cover", border: `1px solid ${palette.border}` }} />
    </div>
  );
}

function SportSection({ sportKey }) {
  const { state } = useData();
  const sport = state.sports[sportKey];
  return (
    <div className="sport-section" style={{ display: "grid", gap: 16 }}>
      <Cover svg={sport.cover} title={`${sport.name} Hub`} />
      <div style={styles.grid}>
        <FixtureList title="Upcoming" items={upcoming(sport.fixtures)} />
        <FixtureList title="Recent Results" items={recent(sport.results).map((r) => ({ ...r }))} />
      </div>
      <Leaderboard sportKey={sportKey} />
    </div>
  );
}

// ===== Editor =====
function Editor({ sportKey }) {
  const { state, setState } = useData();
  const sport = state.sports[sportKey];

  // Local form state
  const [team, setTeam] = useState({ name: "", leagueIndex: 0 });
  const [player, setPlayer] = useState({ name: "", team: "", goals: 0, assists: 0, threeDartAvg: 0, highestCheckout: 0, _180s: 0 });
  const [fixture, setFixture] = useState({ date: "", home: "", away: "" });

  const commit = (producer) => setState((prev) => ({ ...prev, sports: { ...prev.sports, [sportKey]: producer(JSON.parse(JSON.stringify(prev.sports[sportKey]))) } }));

  const addTeam = () => {
    if (!team.name) return;
    commit((s) => { s.leagues[team.leagueIndex ?? 0].teams.push(team.name); return s; });
    setTeam({ name: "", leagueIndex: 0 });
  };

  const addPlayer = () => {
    if (!player.name) return;
    const p = { id: Math.random().toString(36).slice(2), name: player.name, team: player.team };
    if (sportKey === "football") Object.assign(p, { goals: +player.goals || 0, assists: +player.assists || 0, yellow: 0, red: 0 });
    if (sportKey === "darts") Object.assign(p, { threeDartAvg: +player.threeDartAvg || 0, highestCheckout: +player.highestCheckout || 0, "180s": +player._180s || 0 });
    commit((s) => { s.players.push(p); return s; });
    setPlayer({ name: "", team: "", goals: 0, assists: 0, threeDartAvg: 0, highestCheckout: 0, _180s: 0 });
  };

  const addFixture = () => {
    if (!fixture.date || !fixture.home || !fixture.away) return;
    commit((s) => { s.fixtures.push({ id: Math.random().toString(36).slice(2), ...fixture }); return s; });
    setFixture({ date: "", home: "", away: "" });
  };

  return (
    <div style={{ ...styles.card, display: "grid", gap: 16 }}>
      <h3 style={styles.h2}>{sport.name} — Editor</h3>

      {/* Add Team */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 120px", gap: 8 }}>
        <input style={styles.input} placeholder="Team name" value={team.name} onChange={(e) => setTeam({ ...team, name: e.target.value })} />
        <select style={{ ...styles.input, appearance: "none" }} value={team.leagueIndex} onChange={(e) => setTeam({ ...team, leagueIndex: +e.target.value })}>
          {sport.leagues.map((l, i) => (
            <option key={l.id} value={i}>{l.name}</option>
          ))}
        </select>
        <button style={{ ...styles.btn, ...styles.btnPrimary }} onClick={addTeam}>Add Team</button>
      </div>

      {/* Add Player */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr) 120px", gap: 8 }}>
        <input style={styles.input} placeholder="Player name" value={player.name} onChange={(e) => setPlayer({ ...player, name: e.target.value })} />
        <input style={styles.input} placeholder="Team" value={player.team} onChange={(e) => setPlayer({ ...player, team: e.target.value })} />
        {sportKey === "football" ? (
          <>
            <input style={styles.input} placeholder="Goals" type="number" value={player.goals} onChange={(e) => setPlayer({ ...player, goals: e.target.value })} />
            <input style={styles.input} placeholder="Assists" type="number" value={player.assists} onChange={(e) => setPlayer({ ...player, assists: e.target.value })} />
            <div />
            <div />
          </>
        ) : (
          <>
            <input style={styles.input} placeholder="3-dart avg" type="number" value={player.threeDartAvg} onChange={(e) => setPlayer({ ...player, threeDartAvg: e.target.value })} />
            <input style={styles.input} placeholder="Highest checkout" type="number" value={player.highestCheckout} onChange={(e) => setPlayer({ ...player, highestCheckout: e.target.value })} />
            <input style={styles.input} placeholder="180s" type="number" value={player._180s} onChange={(e) => setPlayer({ ...player, _180s: e.target.value })} />
            <div />
          </>
        )}
        <button style={{ ...styles.btn, ...styles.btnPrimary }} onClick={addPlayer}>Add Player</button>
      </div>

      {/* Add Fixture */}
      <div style={{ display: "grid", gridTemplateColumns: "160px 1fr 1fr 120px", gap: 8 }}>
        <input style={styles.input} type="date" value={fixture.date} onChange={(e) => setFixture({ ...fixture, date: e.target.value })} />
        <input style={styles.input} placeholder="Home" value={fixture.home} onChange={(e) => setFixture({ ...fixture, home: e.target.value })} />
        <input style={styles.input} placeholder="Away" value={fixture.away} onChange={(e) => setFixture({ ...fixture, away: e.target.value })} />
        <button style={{ ...styles.btn, ...styles.btnPrimary }} onClick={addFixture}>Add Fixture</button>
      </div>

      <div style={styles.small}>Tip: all changes are in-memory for preview. Persist to your backend in RN/Expo.</div>
    </div>
  );
}

// ===== Dashboard =====
function Dashboard() {
  const { state } = useData();
  const f = state.sports.football;
  const d = state.sports.darts;
  const allUpcoming = [...upcoming(f.fixtures), ...upcoming(d.fixtures)].sort((a, b) => a.date.localeCompare(b.date));
  const allRecent = [...recent(f.results), ...recent(d.results)].sort((a, b) => b.date.localeCompare(a.date));

  const topScorer = f.players.slice().sort((a, b) => b.goals - a.goals)[0];
  const bestAvg = d.players.slice().sort((a, b) => b.threeDartAvg - a.threeDartAvg)[0];

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <section style={styles.card}>
        <div style={styles.hero}>
          <div>
            <h1 style={styles.h1}>TrackMyMatch — Dashboard</h1>
            <div style={styles.small}>Upcoming fixtures, fresh results and player spotlights.</div>
          </div>
          <div style={{ justifySelf: "end", display: "grid", gap: 10 }}>
            <Stat label="Top Scorer (Football)" value={`${topScorer?.name ?? "—"} (${topScorer?.goals ?? 0})`} hint={topScorer?.team} tone="gold" />
            <Stat label="Best 3-dart Avg (Darts)" value={`${bestAvg?.name ?? "—"} (${bestAvg?.threeDartAvg ?? 0})`} hint={bestAvg?.team} tone="pink" />
          </div>
        </div>
      </section>

      <div style={styles.grid}>
        <FixtureList title="Upcoming (All Sports)" items={allUpcoming} />
        <FixtureList title="Recent Results (All Sports)" items={allRecent} />
      </div>

      <div style={styles.grid}>
        <Leaderboard sportKey="football" />
        <Leaderboard sportKey="darts" />
      </div>
    </div>
  );
}

// ===== Contact Us =====
function ContactUs() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  return (
    <div style={{ ...styles.card, display: "grid", gap: 12 }}>
      <h3 style={styles.h2}>Contact Us</h3>
      {!sent ? (
        <>
          <input style={styles.input} placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input style={styles.input} placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <textarea style={{ ...styles.input, minHeight: 100 }} placeholder="Message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          <button style={{ ...styles.btn, ...styles.btnPrimary, justifySelf: "start" }} onClick={() => setSent(true)}>Send</button>
        </>
      ) : (
        <div style={{ color: palette.accent }}>Thanks! We'll get back to you shortly.</div>
      )}
    </div>
  );
}

// ===== Shell / Router =====
function useRouter() {
  const [route, setRoute] = useState({ name: "Dashboard", params: {} });
  const navigate = (name, params = {}) => setRoute({ name, params });
  return { route, navigate };
}

function Nav({ route, navigate }) {
  const tabs = [
    { key: "Dashboard", label: "Dashboard" },
    { key: "Football", label: "Football" },
    { key: "Darts", label: "Darts" },
    { key: "Edit", label: "Edit" },
    { key: "Contact", label: "Contact" },
  ];
  return (
    <div style={styles.header}>
      <div style={{ ...styles.container, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <div style={styles.brand}>
          <div style={styles.brandBadge}>TM</div>
          <div>TrackMyMatch</div>
        </div>
        <nav style={styles.nav}>
          {tabs.map((t) => (
            <button key={t.key} style={styles.tab(route.name === t.key)} onClick={() => navigate(t.key)}>{t.label}</button>
          ))}
        </nav>
      </div>
    </div>
  );
}

function BannerAd() {
  return (
    <div style={styles.banner}>
      <div style={{ ...styles.container }}>
        <div style={{ ...styles.card, textAlign: "center", padding: 14, background: `linear-gradient(90deg, ${palette.accent}22, ${palette.accent2}22)` }}>
          <strong>Sponsored:</strong> Your banner ad goes here — 970×90 leader board.
        </div>
      </div>
    </div>
  );
}

// ===== App =====
export default function App() {
  const { route, navigate } = useRouter();
  return (
    <div style={styles.page}>
      <Nav route={route} navigate={navigate} />
      <DataProvider>
        <main style={{ ...styles.container, display: "grid", gap: 16 }}>
          {route.name === "Dashboard" && <Dashboard />}
          {route.name === "Football" && <SportSection sportKey="football" />}
          {route.name === "Darts" && <SportSection sportKey="darts" />}
          {route.name === "Edit" && (
            <div style={{ display: "grid", gap: 16 }}>
              <Editor sportKey="football" />
              <Editor sportKey="darts" />
            </div>
          )}
          {route.name === "Contact" && <ContactUs />}
        </main>
        <BannerAd />
      </DataProvider>
    </div>
  );
}
